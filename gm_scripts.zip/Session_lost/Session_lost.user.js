// ==UserScript==
// @name        Session lost
// @namespace   window
// @include     https://www.die-staemme.de/sid_wrong.php
// @version     1
// @grant       none
// ==/UserScript==

window.location.href = "https://www.die-staemme.de/";